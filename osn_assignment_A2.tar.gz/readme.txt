Multiple_Flow_tables folder contains 1 folder(curls), 3 files generated as a result of script command on each of the hosts to check the working of the openflow tables,flows.txt,curls_matched.doc,tables.doc containing the table information with priorities of the flows.

The folder curls contains 17 curl command which were executed with the help of one bash script curls.sh,this bash script runs and installs all the 17 flows at one shot.

flows.txt contains all the flows which are presented table-wise and also before each table's flows the side-notes are also presented.

curls_matched.doc contains table contains 3 columns curls,functionality and table no. & flow no.

tables.doc contains the table information with the priorities of the flows.

Controller used : RYU,openflow version 1.3.
