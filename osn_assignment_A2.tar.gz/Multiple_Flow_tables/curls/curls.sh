#!/bin/bash  
echo "This is a shell script"  
./curl_1.txt
echo "I am done first curl"
./curl_2.txt
echo "I am done 2 curl"  
./curl_3.txt
echo "I am done 3 curl"  
./curl_4.txt
echo "I am done 4 curl"  
./curl_5.txt
echo "I am done 5 curl"  
./curl_6.txt
echo "I am done 6 curl"  
./curl_7.txt
echo "I am done 7 curl"  
./curl_8.txt
echo "I am done 8 curl"  
./curl_9.txt
echo "I am done 9 curl"  
./curl_10.txt
echo "I am done 10 curl"  
./curl_11.txt
echo "I am done 11 curl"  
./curl_12.txt
echo "I am done 12 curl"  
./curl_13.txt
echo "I am done 13 curl"  
./curl_14.txt
echo "I am done 14 curl"  
./curl_15.txt
echo "I am done 15 curl"  
./curl_16.txt
echo "I am done 16 curl"  
./curl_17.txt
echo "I am done 17 curl"  
echo "DONE WITH ALL"
